package aula.sala.mssala;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsSalaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsSalaApplication.class, args);
    }

}
