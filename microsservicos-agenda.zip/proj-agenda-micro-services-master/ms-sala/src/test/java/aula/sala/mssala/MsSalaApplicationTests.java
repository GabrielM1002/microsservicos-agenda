package aula.sala.mssala;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsSalaApplicationTests {

    @Test
    void contextLoads() {
    }

}
