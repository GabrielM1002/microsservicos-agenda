package aula.agenda.msagenda.control;


import aula.agenda.msagenda.control.dto.AgendaDTO;
import aula.agenda.msagenda.model.Agenda;
import aula.agenda.msagenda.repository.AgendaRepositorio;
import aula.agenda.msagenda.service.AgendaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import aula.agenda.msagenda.service.AgendaService;

import java.util.List;

@RestController
@RequestMapping("/agenda")
public class AgendaController {

    @Autowired
    private AgendaService agendaService;
    @Autowired
    private AgendaRepositorio agendaRepositorio;

    @GetMapping("/")
    public List<AgendaDTO> listarTodasAgenda(){
        return agendaService.listarAgendas();
    }

    @PostMapping("/")
    public void inserirAgenda(@RequestBody AgendaDTO agendaDTO){
        agendaService.salvar(agendaDTO);
    }

}
