package aula.agenda.msagenda.control.dto;

public class DadosFuncionarioDTO {

    private Long id;

    private String nome;

    public DadosFuncionarioDTO() {
    }

    public DadosFuncionarioDTO(String nome) {this.nome = nome; }

    public DadosFuncionarioDTO(Long id) {this.id = id; }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
