package aula.agenda.msagenda.service;

import aula.agenda.msagenda.control.dto.AgendaDTO;
import aula.agenda.msagenda.control.dto.DadosFuncionarioDTO;
import aula.agenda.msagenda.control.dto.DadosSalaDTO;
import aula.agenda.msagenda.model.Agenda;
import aula.agenda.msagenda.repository.AgendaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;


@Service
public class AgendaService {
    @Autowired
    private AgendaRepositorio agendaRepositorio;
    @Autowired
    private RestTemplate restTemplate;

    private static final String HTTP_FUNCIONARIO_FUNCIONARIO_ID = "http://funcionario/funcionario/";
    private static final String HTTP_SALA_SALA_ID = "http://sala/sala/";


    public List<AgendaDTO> listarAgendas() {
        List<Agenda> agendaList = agendaRepositorio.findAll();
        List<AgendaDTO> infoListDTOS = new ArrayList<>();
        for (Agenda agenda:agendaList) {
            AgendaDTO agendaDTO = new AgendaDTO(agenda);
            DadosFuncionarioDTO dadosFuncionarioDTO = consumirFuncionario(agendaDTO);
            agendaDTO.setResponsavel(dadosFuncionarioDTO.getNome());
            DadosSalaDTO dadosSalaDTO = consumirSalas(agendaDTO);
            agendaDTO.setSala(dadosSalaDTO.getNome());
            infoListDTOS.add(agendaDTO);
        }
        return infoListDTOS;
    }
    //CONSUMIR FUNCIONARIOS
    private DadosFuncionarioDTO consumirFuncionario(AgendaDTO agendaDTO) {
        ResponseEntity<DadosFuncionarioDTO> exchangeresp =
                restTemplate.exchange(HTTP_FUNCIONARIO_FUNCIONARIO_ID + agendaDTO.getIdResponsavel(),
                        HttpMethod.GET, null, DadosFuncionarioDTO.class);
        DadosFuncionarioDTO funcionarioDTO = exchangeresp.getBody();
        return funcionarioDTO;
    }

    //CONSUMIR SALAS
    private DadosSalaDTO consumirSalas(AgendaDTO agenda) {
        ResponseEntity<DadosSalaDTO> exchangesala = restTemplate.exchange(HTTP_SALA_SALA_ID + agenda.getIdSala(), HttpMethod.GET, null, DadosSalaDTO.class);
        DadosSalaDTO dadosSalaDTO = exchangesala.getBody();
        return dadosSalaDTO;
    }
    //SALVAR
    public void salvar(AgendaDTO agendaDTO) {
        DadosFuncionarioDTO funcionarioDTO = consumirFuncionario(agendaDTO);
        DadosSalaDTO salaDTO = consumirSalas(agendaDTO);
        Agenda agenda = agendaDTO.converteParaAgenda();
        agendaRepositorio.save(agenda);
    }
}
