package aula.agenda.msagenda.repository;

import aula.agenda.msagenda.model.Agenda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AgendaRepositorio extends JpaRepository<Agenda,Long> {
}
