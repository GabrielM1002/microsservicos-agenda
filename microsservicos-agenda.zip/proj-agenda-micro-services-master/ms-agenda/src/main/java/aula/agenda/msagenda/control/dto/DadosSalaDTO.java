package aula.agenda.msagenda.control.dto;

public class DadosSalaDTO {

    private String nome;

    private Integer numeroLugares;

    public DadosSalaDTO() {
    }

    public DadosSalaDTO(String nome) {
        this.nome = nome;
    }

    public DadosSalaDTO(Integer numeroLugares) {
        this.numeroLugares = numeroLugares;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getNumeroLugares() {
        return numeroLugares;
    }

    public void setNumeroLugares(Integer numeroLugares) {
        this.numeroLugares = numeroLugares;
    }
}
