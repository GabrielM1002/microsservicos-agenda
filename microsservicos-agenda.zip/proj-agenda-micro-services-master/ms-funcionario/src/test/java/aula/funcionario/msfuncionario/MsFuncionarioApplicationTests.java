package aula.funcionario.msfuncionario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsFuncionarioApplicationTests {

    @Test
    void contextLoads() {
    }

}
